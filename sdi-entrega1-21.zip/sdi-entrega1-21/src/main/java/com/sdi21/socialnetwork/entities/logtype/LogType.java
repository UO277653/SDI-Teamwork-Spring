package com.sdi21.socialnetwork.entities.logtype;

public enum LogType {
    PET,
    ALTA,
    LOGIN_EX,
    LOGIN_ERR,
    LOGOUT

}
